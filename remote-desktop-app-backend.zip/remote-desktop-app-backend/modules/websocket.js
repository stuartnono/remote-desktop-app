const { spawn } = require('child_process');
const robot = require('robotjs');

module.exports = (io) => {
    io.on('connection', (socket) => {
        console.log(`User connected: ${socket.id}`);

        // Function to start FFmpeg and stream screen data
        function startScreenStream() {
            const ffmpeg = spawn('ffmpeg', [
                '-f', 'gdigrab',
                '-i', 'desktop',
                '-framerate', '15',
                '-video_size', '1280x720',
                '-f', 'mpegts', '-',
            ]);

            // Handle FFmpeg stdout (screen data)
            ffmpeg.stdout.on('data', (data) => {
                socket.emit('screenData', data);
            });

            // Handle FFmpeg stderr (errors)
            ffmpeg.stderr.on('data', (errorData) => {
                console.error('FFmpeg error:', errorData.toString());
                socket.emit('error', 'Error capturing screen: ' + errorData.toString());
            });

            // Handle FFmpeg process errors (e.g., if FFmpeg fails to start)
            ffmpeg.on('error', (err) => {
                console.error('Failed to start FFmpeg process:', err);
                socket.emit('error', 'Error starting screen capture');
            });

            // Clean up on disconnect
            socket.on('disconnect', () => {
                console.log('User disconnected:', socket.id);
                ffmpeg.kill('SIGINT');
            });

            return ffmpeg;
        }

        // Start the FFmpeg stream
        let ffmpegProcess = startScreenStream();

        // Restart FFmpeg on refresh request
        socket.on('refreshScreen', () => {
            console.log('Refresh requested');
            if (ffmpegProcess) {
                ffmpegProcess.kill('SIGINT');
            }
            ffmpegProcess = startScreenStream();
        });

        // Mouse and keyboard controls
        socket.on('mouseMove', (data) => {
            try {
                robot.moveMouse(data.x, data.y);
            } catch (err) {
                console.error('Error moving mouse:', err);
                socket.emit('error', 'Error moving mouse: ' + err.message);
            }
        });

        socket.on('keyPress', (keys) => {
            try {
                keys.forEach((key) => {
                    robot.keyTap(key);
                });
            } catch (err) {
                console.error('Error pressing keys:', err);
                socket.emit('error', 'Error pressing keys: ' + err.message);
            }
        });

        // Handle any WebSocket errors
        socket.on('error', (error) => {
            console.error('WebSocket error:', error);
            socket.emit('error', 'WebSocket connection error: ' + error);
        });
    });
};
